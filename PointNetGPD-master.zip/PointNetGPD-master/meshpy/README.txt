This is a 3D mesh processing library, courtesty of
the Berkeley AutoLab and Jeff Mahler.

To run unit tests, from the top level directory simply run
>>> python -m unittest discover
